# Let's all discuss before initial merge. 
Project 3

## If you are modifying 




## Github Flow 
```
Create a branch. Create a branch(copy) of main.... call it whatever you want to call it vs code.  ...
Make changes. On your branch, make any desired changes to the repository. .. vs code applocked at the moment. 
Create a pull request. Create a pull request to ask collaborators for feedback on your changes. ...
Address review comments. ...
Merge your pull request...       we can decide we two of us we want to be able to merge
Delete your branch.
create branch and push to your repo

```




![git-workflow-1](https://user-images.githubusercontent.com/49794872/221347452-256d9ef5-f923-47a2-ac2e-10d81702a317.png)


